/* Parallaxe très discret (désactivé si « réduire les animations ») */
(function(){if(matchMedia('(prefers-reduced-motion: reduce)').matches)return;
var els=[].slice.call(document.querySelectorAll('[data-parallax]'));if(!els.length)return;var t=false;
function u(){t=false;var y=window.scrollY;if(y>900)return;els.forEach(function(e){e.style.transform='translate3d(0,'+(y*0.08).toFixed(1)+'px,0)'})}
window.addEventListener('scroll',function(){if(!t){t=true;requestAnimationFrame(u)}},{passive:true})})();
/* Visionneuse plein écran (flèches, Échap, clic hors image) */
(function(){var links=[].slice.call(document.querySelectorAll('[data-lightbox]'));if(!links.length)return;
var lb=document.createElement('div');lb.className='lb';lb.setAttribute('role','dialog');lb.setAttribute('aria-modal','true');
lb.innerHTML='<button class="x" type="button" aria-label="Fermer">×</button><button class="pv" type="button" aria-label="Précédent">‹</button><img alt=""><button class="nx" type="button" aria-label="Suivant">›</button>';
document.body.appendChild(lb);var img=lb.querySelector('img'),i=0;
function live(){return links.filter(function(a){return document.contains(a)})}
function show(n){var L=live();if(!L.length)return;i=(n+L.length)%L.length;img.src=L[i].getAttribute('href');img.alt=(L[i].querySelector('img')||{}).alt||''}
function open(a){var L=live();show(L.indexOf(a));lb.classList.add('open');document.body.style.overflow='hidden'}
function close(){lb.classList.remove('open');document.body.style.overflow=''}
links.forEach(function(a){a.addEventListener('click',function(e){e.preventDefault();open(a)})});
lb.addEventListener('click',function(e){if(e.target===lb)close()});
lb.querySelector('.x').onclick=close;lb.querySelector('.pv').onclick=function(){show(i-1)};lb.querySelector('.nx').onclick=function(){show(i+1)};
document.addEventListener('keydown',function(e){if(!lb.classList.contains('open'))return;if(e.key==='Escape')close();if(e.key==='ArrowLeft')show(i-1);if(e.key==='ArrowRight')show(i+1)})})();
